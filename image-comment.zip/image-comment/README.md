### Thêm field created_at vào database
    alter table `comment` add column created_at datetime default now()

### Đổi đường dẫn trong tag img thành đường dẫn của art và user_image