<?php

const HOST_DB = 'localhost';
const DB = 'image_comment';
const USER_DB = 'root';
const PASS_DB = 'root';

const BASE_URL = 'http://localhost:80/image-comment';